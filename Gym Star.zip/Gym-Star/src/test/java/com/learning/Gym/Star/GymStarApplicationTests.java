package com.learning.Gym.Star;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymStarApplicationTests {

	@Test
	void contextLoads() {
	}

}
